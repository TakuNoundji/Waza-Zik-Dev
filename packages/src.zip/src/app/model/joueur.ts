export class Joueur {
    username: string;
    score: number;
  
    constructor(username: string, score: number) {
      this.username = username;
      this.score = score;
    }
  }