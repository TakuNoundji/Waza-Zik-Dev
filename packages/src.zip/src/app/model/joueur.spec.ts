import { Joueur } from './joueur';

describe('Joueur', () => {
  it('should create an instance', () => {
    expect(new Joueur()).toBeTruthy();
  });
});
